﻿using System;
using System.Windows;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;


namespace Ticker1Service
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
    public class Service1 : IService1
    {
       
        Random r1 = new Random();
        Random r2 = new Random();
        public double GetCurrentPriceForStock1()
        {
            int min = 240, max = 270;

            int d = r1.Next(0, 99);
            return r1.Next(min, max) + (d == 0 ? 0 : d / 100.00);
        }
        public double GetCurrentPriceForStock2()
        {
            int min = 180, max = 210;

            int d = r2.Next(0, 99);
            return r2.Next(min, max) + (d == 0 ? 0 : d / 100.00);
        }
    }
}
