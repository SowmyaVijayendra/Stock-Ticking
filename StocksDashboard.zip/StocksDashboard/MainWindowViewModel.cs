﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls.Primitives;
using System.Windows.Threading;

namespace StocksDashboard
{
    internal class MainWindowViewModel:INotifyPropertyChanged
    {
        private PresentationLogic presenter;
        private Stock stock1;
        private Stock stock2;
        
        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public Stock Stock1
        {
            get { return stock1; }
            set { stock1 = value;
                OnPropertyChanged();
            }
        }

        public Stock Stock2
        {
            get { return stock2; }
            set { stock2 = value;
                OnPropertyChanged();
            }
        }
        
        public MainWindowViewModel()
        {
            presenter = new PresentationLogic();
            InitializeStocks();
            var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            timer.Tick += Timer_Tick;
            timer.Start();
        }
        private void Timer_Tick(object sender, EventArgs e)
        {
            Stock1.CurrentPrice = presenter.GetCurrentPriceForStock1();
            Stock2.CurrentPrice = presenter.GetCurrentPriceForStock2();
        }
        private void InitializeStocks()
        {
            Stock1 = new Stock() {
                StockName = "Stock1",
                PriceHistory = new ObservableCollection<StockHistory>()           
        };
            Stock2 = new Stock() { 
                StockName = "Stock2",
                PriceHistory = new ObservableCollection<StockHistory>()
            };
        }
    }
}
