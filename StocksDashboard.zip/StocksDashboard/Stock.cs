﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace StocksDashboard
{
    /// <summary>
    /// Entity for Stock
    /// </summary>
    public class Stock : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;


        public void OnPropertyChanged(string propertyname)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyname));
            }
        }


        private string stockName;
        public string StockName
        {
            get { return stockName; }
            set
            {
                stockName = value;
                OnPropertyChanged("StockName");
            }
        }
       
        private double price;
        public double CurrentPrice
        {
            get { return price; }
            set
            {
                SetProperties(value);
            }
        }
        private string displayPrice;
        public string DisplayPrice
        {
            get { return displayPrice; }
            set
            {
                displayPrice = value;
                OnPropertyChanged("DisplayPrice");
            }
        }
        private SolidColorBrush background;
        public SolidColorBrush Background
        {
            get { return background; }
            set
            {
                background = value;
                OnPropertyChanged("Background");
            }
        }
        private ObservableCollection<StockHistory> priceHistory;
        public ObservableCollection<StockHistory> PriceHistory
        {
            get { return priceHistory; }
            set
            {
                priceHistory = value;
            }
        }

        private string date;
        public string Date
        {
            get { return date; }
            set
            {
                date = value;
            }
        }

        private void SetProperties(double value)
        {
            if (price == value)
                Background = Brushes.White;
            else if (price > value)
                Background = Brushes.Red;
            else Background = Brushes.Green;
            price = value;
            Date = System.DateTime.Now.ToString("dd MMM yyyy HH:mm:ss");
            DisplayPrice = price.ToString("#.00");
            PriceHistory.Add(new StockHistory() { Date = this.Date, DisplayPrice = this.displayPrice });

        }
    }
    public class StockHistory
    {
        private string displayPrice;
        public string DisplayPrice
        {
            get { return displayPrice; }
            set
            {
                displayPrice = value;

            }
        }
        private string date;
        public string Date
        {
            get { return date; }
            set
            {
                date = value;

            }
        }
    }
}
