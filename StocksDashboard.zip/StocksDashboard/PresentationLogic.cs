﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace StocksDashboard
{
    internal class PresentationLogic
    {
      ServiceReference1.Service1Client client = new ServiceReference1.Service1Client();
        internal double GetCurrentPriceForStock1()
        {
             return client.GetCurrentPriceForStock1();           
        }

        internal double GetCurrentPriceForStock2()
        {
            return client.GetCurrentPriceForStock2();           
        }
    }
}
